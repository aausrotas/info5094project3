<html>
	<head>
		<title>INFO-5094 Project</title>
	</head>
	<body>
		<ul>
			<li> Part 1<br/>
				<ul>
					<li><a href="getData/index.php?action=load">Upload Path Data File</a><br/></li>
				</ul>
			</li>
			<li> Part 3<br/>
				<ul>
					<li><a href="getData/includes/displayData.php?action=load">Edit Path Data File</a><br/></li>
				</ul>
			</li>
		</li>
	</body>
</html>
