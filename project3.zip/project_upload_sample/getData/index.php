<?php
	session_start();

	require_once("./includes/loadPathData.php");

?>
<html>
<head>
	<title>Microwave Path</title>
	<script src="../js/jquery-3.3.1.min.js" type="text/javascript"></script>
</head>
<body>
<?php 
	if (isset($_SERVER['REQUEST_METHOD']) &&  $_SERVER['REQUEST_METHOD'] == "GET"){
		if (isset($_GET['action']) && $_GET['action'] == "load"){
			loadPathForm();
		} else {
			displayInvalidRequest();
		}
	} else if (isset($_SERVER['REQUEST_METHOD']) &&  $_SERVER['REQUEST_METHOD'] == "POST"){
		if (isset($_POST['uploadPathFile']) && $_POST['uploadPathFile'] == "Upload"){
			$err_msgs = validatePathFile();
			if (count($err_msgs)){
				displayErrors($err_msgs);
				loadPathFomr();
			} else {
				$status = savePathData();
				displayStatus($status);
			}
		}
	} else {
		displayInvalidRequest();
	}
?>
</body>
</html>
<?php
function displayInvalidRequest(){
	echo "<h2> Invlaid Request, please return to the main menu and make another selection</h2>\n";
	echo "<a href=\"../index.php\"> Return to Main Main</a>\n";
}
function displayStatus($status){
	echo "<h2> Path information ".$status." </h2>\n";
	echo "<a href=\"../index.php\"> Return to Main Main</a>\n";
}
function displayErrors($err){
	echo "<h3> The following errors were found</h3>\n";
	foreach ($err as $e){
		echo "<p>".$e."</p>\n";
	}
	echo "\n";
}
?>
